package com.santiago.posada.routes;

public class ErrorResponse {
    String message;

    public ErrorResponse(String message) {
        this.message = message;
    }
}
