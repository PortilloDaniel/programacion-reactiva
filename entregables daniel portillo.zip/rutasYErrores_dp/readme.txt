el objetivo de este entregable fue completar el metodo de eliminación de la clase ToDoService
los entry points del proyecto para los servicios de obtención, creación, actulización y eliminación 
de una tarea
y por ultimo la respuesta correcta en caso de error