package org.example;

public class Iva implements IIva {
    @Override
    public int CalcularIva(int ventas) {
        return ((ventas*21)/100);
    }
    @Override
    public int CalcularIva(int ventas, int iva) {
        return ((ventas*iva)/100);
    }
}