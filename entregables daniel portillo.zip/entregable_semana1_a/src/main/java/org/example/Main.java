package org.example;

import java.util.List;

public class Main {

    public static void main(String[] args) {
        Main m = new Main();
        m.ejercicio1();
        m.ejercicio2();
        m.ejercicio3();
    }


    public void ejercicio1(){
        System.out.println("Ejecutando ejercicio 1");
        List <Integer> misNumeros = List.of(101,33,41,35,32,6,83,123,12);
        MayorMenor Ejercicio1=new MayorMenor();
        System.out.println("El numero con mayor valor obtenido es:" );
        Ejercicio1.getMayor(misNumeros);
        System.out.println("El numero con menor valor obtenido es:" );
        Ejercicio1.getMenor(misNumeros);
    }

    public void ejercicio2(){
        System.out.println("Ejecutando ejercicio 2");

        int valorVentas = 325000;
        int porcentajeDescuento = 25;

        Descuento ejercicio2 = new Descuento();
        System.out.println("El valor de la venta es: " + valorVentas + " $");
        System.out.println("El porcentaje de descuento es: " + porcentajeDescuento + "%");
        System.out.println("El valor de la venta con descuento es: ");
        System.out.println(ejercicio2.CalcularDescuento(valorVentas, porcentajeDescuento));

    }

    public void ejercicio3(){
        System.out.println("Ejecutando ejercicio 3");
        int precio = 32000;
        int iva = 8;
        Iva ejercicio3= new Iva();
        System.out.println("Prueba con iva establecido: 21%");
        System.out.println(ejercicio3.CalcularIva(precio,iva));
        System.out.println("Prueba con: "+ iva +"% de iva");
        System.out.println(ejercicio3.CalcularIva(precio));

    }
}