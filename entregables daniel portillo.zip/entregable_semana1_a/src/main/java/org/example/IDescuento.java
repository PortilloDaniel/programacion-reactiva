package org.example;

public interface IDescuento {
    public int CalcularDescuento (int Ventas, int Descuento);
}

