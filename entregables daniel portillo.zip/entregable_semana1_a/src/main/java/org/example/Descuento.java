package org.example;

public class Descuento implements IDescuento {

    @Override
    public int CalcularDescuento(int Ventas, int Descuento) {
        return Ventas-(Ventas*Descuento/100);
    }
}
