package org.example;

import java.util.List;

public interface INumMayorMenor {
    public void getMayor(List<Integer> list);
    public void getMenor(List<Integer> list);
}
