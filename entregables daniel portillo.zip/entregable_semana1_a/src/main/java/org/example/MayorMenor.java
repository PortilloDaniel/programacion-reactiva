package org.example;

import java.util.List;

public class MayorMenor implements INumMayorMenor {

    @Override
    public void getMayor(List<Integer> list) {
        System.out.println(list.stream().max(Integer::compareTo).get());
    }

    @Override
    public void getMenor(List<Integer> list) {
        System.out.println(list.stream().min(Integer::compareTo).get());
    }
}
