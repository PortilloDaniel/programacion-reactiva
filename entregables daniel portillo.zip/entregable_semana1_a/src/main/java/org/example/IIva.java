package org.example;

public interface IIva {
    public int CalcularIva(int Valor, int Iva);
    public int CalcularIva(int Valor);

}