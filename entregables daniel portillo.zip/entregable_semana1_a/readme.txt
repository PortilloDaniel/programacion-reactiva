Contiene la solución de 3 ejercicios por medio del uso de interfaces
Calcular el iva
Obtener un descuento
Obtener el numero mayor y menor de una arreglo de numeros