el objetivo de este entregable fue desarrollar las pruebas de forma reactiva y no reactiva
para diferentes casos 