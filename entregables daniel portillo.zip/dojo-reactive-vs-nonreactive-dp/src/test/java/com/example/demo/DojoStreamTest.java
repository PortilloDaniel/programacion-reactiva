package com.example.demo;


import org.junit.jupiter.api.Test;
import reactor.core.publisher.Flux;

import java.util.*;
import java.util.function.BiConsumer;
import java.util.function.BinaryOperator;
import java.util.function.Function;
import java.util.stream.Collectors;

public class DojoStreamTest {

    @Test
    void converterData(){
        List<Player> list = CsvUtilFile.getPlayers();
        assert list.size() == 18207;
    }

    @Test
    void jugadoresMayoresA35(){
        List<Player> list = CsvUtilFile.getPlayers();
        list.stream().filter(player -> player.getAge()>35).forEach(System.out::println);
    }

    @Test
    void jugadoresMayoresA35SegunClub(){
        List<Player> list = CsvUtilFile.getPlayers();
        Map<String, List<Player>> result = list.stream()
                .filter(player -> player.getAge() > 35)
                .collect(Collectors.groupingBy(Player::getClub));
        result.forEach((s, players) -> {
            System.out.println(s);
            players.forEach(System.out::println);
        });
    }

    @Test
    void mejorJugadorConNacionalidadFrancia(){
        List<Player> list = CsvUtilFile.getPlayers();
        list.stream().filter(p -> p.getNational().equals("France"))
                .reduce((j1, j2)-> j1.getWinners() > j2.getWinners() ? j1 : j2)
                .ifPresent(System.out::println);
    }


    @Test
    void clubsAgrupadosPorNacionalidad(){
        List<Player> list = CsvUtilFile.getPlayers();
        Function<Player, List<Object>> compositeKey = r -> Arrays.<Object>asList(r.getNational(), r.getClub());
        Map<Object, List<Player>> map =
                list.stream().collect(Collectors.groupingBy(compositeKey, Collectors.toList()));
        map.forEach((o, players) -> {
            System.out.println(o);
            players.forEach(System.out::println);
        });
    }

    @Test
    void clubConElMejorJugador(){
        List<Player> list = CsvUtilFile.getPlayers();
        list.stream().max(Comparator.comparing(player -> player.getWinners()/ player.getGames()))
                .ifPresent(player -> {
                    System.out.println("Club con mejor jugador: "+player.getClub());
                    System.out.println(player);
                });
    }

    @Test
    void ElMejorJugador(){
        List<Player> list = CsvUtilFile.getPlayers();
        list.stream().reduce((j1, j2)-> j1.getWinners() > j2.getWinners() ? j1 : j2)
                .ifPresent(p -> System.out.println("El mejor jugador: " + p.getName() + "\n" + p));
    }

    @Test
    void mejorJugadorSegunNacionalidad(){
        List<Player> list = CsvUtilFile.getPlayers();
        list.stream().collect(Collectors.groupingBy(Player::getNational)).forEach((s, players) -> {
            players.stream().max(Comparator.comparing(player -> player.getWinners()/player.getGames()))
                    .ifPresent(player -> System.out.println("Mejor jugador de "+s+"\n"+player));
        });
    }


}
