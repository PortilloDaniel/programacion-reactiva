package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApplicationTests {

	@Test
	void jugadoresMayoresA35(){

	}

	@Test
	void mejorJugadorConNacionalidadFrancia(){

	}

	@Test
	void clubsAgrupadosPorNacionalidad(){

	}

	@Test
	void clubConElMejorJugador(){

	}


	@Test
	void mejorJugadorSegunNacionalidad(){

	}
}
