Contiene la solución de los puntos 6 a 10 
donde se calculan valores como:
el monto total pagado de cada venta
Compras hechas por mujeres
Agrupación de items por etiquetas
Cupones redimidos por cada genero 
Venta con mayor y menor costo