import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Funciones funciones = new Funciones();
        gestionDeTurnos(funciones);
    }

    private static void gestionDeTurnos(Funciones funciones) {
        Scanner sc = new Scanner(System.in);
        Scanner sc2 = new Scanner(System.in);

        System.out.println("" +
                "1- Inscribir Asesor de turno\n" +
                "2- Agregar cliente \n" +
                "3- Salir");
        int menuOption = sc.nextInt();
        switch (menuOption){
            case 1:
                System.out.println("Agregue el nombre del asesor de turno");
                String nuevoAsesor = sc2.nextLine();
                AsesorObserver asesor = new AsesorObserver(nuevoAsesor);
                funciones.agregarAsesor(asesor);
                System.out.println("Asesor inscrito exitosamente.");
                gestionDeTurnos(funciones);
                break;

            case 2:
                System.out.println("Agregue el nombre del nuevo cliente");
                String nombreNuevoUsuario = sc2.nextLine();
                Usuario nuevoUsuario = new Usuario(nombreNuevoUsuario);
                funciones.agregarUsuario(nuevoUsuario);
                gestionDeTurnos(funciones);
                break;

            case 3:
                System.out.println("Gracias por utilizar nuestro sistema!");
                break;
            default:
                System.out.println("Opción incorrecta");
        }
        sc.close();
        sc2.close();
    }
}