public class AsesorObserver implements IAsesorObserver {

    private String nombreAsesor;


    public AsesorObserver(String nombreAsesor) {
        this.nombreAsesor = nombreAsesor;

    }

    @Override
    public void update(String name) {
        System.out.println(this.nombreAsesor +" Se ha agregado un nuevo usuario, su nombre: " + name);
    }

    public String getNombreAsesor() {
        return nombreAsesor;
    }
}
