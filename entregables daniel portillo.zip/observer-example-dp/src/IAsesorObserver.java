public interface IAsesorObserver {
    void update(String name);
}
