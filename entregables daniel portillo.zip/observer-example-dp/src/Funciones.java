import java.util.ArrayList;

public class Funciones {
    private ArrayList<IAsesorObserver> IAsesorObservers;

    public Funciones() {
        this.IAsesorObservers = new ArrayList<>();
    }

    public void agregarUsuario(Usuario usuario){
        notifyObservers(usuario);
    }
    public void agregarAsesor(IAsesorObserver IAsesorObserver) {
        IAsesorObservers.add(IAsesorObserver);
    }

    public void notifyObservers(Usuario usuario) {
        IAsesorObservers.forEach(IAsesorObserver -> IAsesorObserver.update(usuario.getNombre()));
    }
}
