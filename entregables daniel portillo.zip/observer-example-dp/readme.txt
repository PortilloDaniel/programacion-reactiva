El ejercicio consistía en crear un observador 

La solución tiene como objetivo asignar clientes a un asesor
en ella se permite registrar un asesor de turno y a ese asesor irle asignando cliente para atender